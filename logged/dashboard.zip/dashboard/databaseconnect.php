<?php
    
    $db = mysqli_connect("localhost", "wcewlugo_root", "Developer@1234", "wcewlugo_test")
   ?>