<?php
session_start();
if(!empty($_SESSION["userId"])) {
    require_once './view/add_entry_form.php';
} else {
    require_once './view/login-form.php';
}
?>








