<?php
session_start();
if(!empty($_SESSION["userId"])) {
    require_once './view/entries_by_me.php';
} else {
    require_once './view/login-form.php';
}
?>